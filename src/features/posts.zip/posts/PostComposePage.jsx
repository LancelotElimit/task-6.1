import React, { useState } from 'react';
import PostTypeSelector from './PostTypeSelector/PostTypeSelector';
import QuestionForm from './QuestionForm/QuestionForm';
import ArticleForm from './ArticleForm/ArticleForm';
import PostButton from './PostButton/PostButton';
import { createQuestion, createArticle } from '../../services/posts';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";



export default function PostComposePage() {
    const [type, setType] = useState('question');
    const [question, setQuestion] = useState({ title: '', body: '', tags: '', imageFile: null });
    const [article, setArticle] = useState({ title: '', abstract: '', text: '', tags: '', imageFile: null });
    const [loading, setLoading] = useState(false);
    const nav = useNavigate();

    const handlePost = async () => {
        try {
            setLoading(true);
            if (type === 'question') {
                await createQuestion(question);
                setQuestion({ title: '', body: '', tags: '', imageFile: null });
            } else {
                await createArticle(article);
                setArticle({ title: '', abstract: '', text: '', tags: '', imageFile: null });
            }
            alert('Posted successfully!');
        } catch (e) {
            console.error(e);
            alert('Failed to post, please try again.');
        } finally {
            setLoading(false);
        }
    };

    const isDisabled =
        (type === 'question' && !question.title.trim()) ||
        (type === 'article' && (!article.title.trim() || !article.abstract.trim()));

    return (
        <div style={{background: '#f8fafc', border: '1px solid #e5e7eb', borderRadius: 14, padding: 16}}>
            <div style={{textAlign: 'right', marginBottom: 8}}>
                <Link to="/posts/find">Go to Find Question →</Link>

            </div>

            <PostTypeSelector value={type} onChange={setType}/>
            <hr style={{border: 0, borderTop: '1px solid #e5e7eb', margin: '12px 0'}}/>

            {type === 'question' ? (
                <QuestionForm values={question} onChange={setQuestion}/>
            ) : (
                <ArticleForm values={article} onChange={setArticle}/>
            )}

            <hr style={{border: 0, borderTop: '1px solid #e5e7eb', margin: '16px 0'}}/>
            <PostButton onClick={handlePost} disabled={isDisabled} loading={loading}/>
        </div>

    );
}
