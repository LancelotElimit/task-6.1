import React, { useEffect, useMemo, useState } from 'react';
import { listQuestions, removeQuestion } from '../../services/posts';

export default function FindQuestionPage() {
    const [items, setItems] = useState([]);
    const [q, setQ] = useState('');
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState('');

    async function reload() {
        try {
            setErr('');
            setLoading(true);
            const rows = await listQuestions();
            setItems(rows);
        } catch (e) {
            console.error('[listQuestions failed]', e);
            setErr('加载问题列表失败，请稍后再试');
        } finally {
            setLoading(false);
        }
    }
    useEffect(() => { reload(); }, []);

    const filtered = useMemo(() => {
        const s = q.trim().toLowerCase();
        if (!s) return items;
        return items.filter(it =>
            (it.title || '').toLowerCase().includes(s) ||
            (it.tagsText || '').toLowerCase().includes(s)
        );
    }, [items, q]);

    async function onDelete(id) {
        if (!window.confirm('Delete this question?')) return;
        await removeQuestion(id);
        await reload();
    }

    const fmtDate = (it) => {
        // Firestore serverTimestamp 可能初始为 null，需要判空
        const d = it?.createdAt?.toDate ? it.createdAt.toDate() : null;
        return d ? d.toLocaleString() : '—';
    };

    return (
        <div style={{ padding: 16 }}>
            <h2>Find Question</h2>

            <input
                type="text"
                placeholder="Filter by title or tags…"
                value={q}
                onChange={e => setQ(e.target.value)}
                style={{ width: '100%', marginBottom: 12 }}
            />

            {loading && <div style={{color:'#666'}}>Loading…</div>}
            {err && <div style={{color:'#b91c1c'}}>{err}</div>}

            {!loading && !err && filtered.length === 0 && (
                <div style={{color:'#666'}}>没有匹配的结果</div>
            )}

            <ul style={{ listStyle: 'none', padding: 0 }}>
                {filtered.map(it => (
                    <li key={it.id}
                        style={{ background: '#fff', border: '1px solid #eee', borderRadius: 12, padding: 12, marginBottom: 10 }}>
                        <div style={{ display:'flex', justifyContent:'space-between', gap:8, alignItems:'baseline' }}>
                            <div style={{ fontWeight: 600 }}>{it.title || '(Untitled)'}</div>
                            <div style={{ color:'#94a3b8', fontSize:12 }}>{fmtDate(it)}</div>
                        </div>

                        {it.imageUrl && (
                            <img src={it.imageUrl} alt=""
                                 style={{ maxWidth: '100%', marginTop: 8, borderRadius: 8 }} />
                        )}

                        {(it.body || it.content) && (
                            <p
                                style={{
                                    marginTop: 8,
                                    whiteSpace: 'pre-wrap',
                                    lineHeight: 1.6
                                }}
                            >{it.body || it.content}</p>
                        )}

                        <div style={{ marginTop: 8, display:'flex', gap:6, flexWrap:'wrap' }}>
                            {(it.tagsArray || []).map(tag => (
                                <span key={tag} style={{
                                    fontSize:12,
                                    background:'#f1f5f9',
                                    border:'1px solid #e2e8f0',
                                    padding:'2px 6px',
                                    borderRadius:999
                                }}>
                                       {tag}
                                   </span>
                            ))}
                        </div>

                        <button onClick={() => onDelete(it.id)} style={{ marginTop: 10 }}>
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
}
